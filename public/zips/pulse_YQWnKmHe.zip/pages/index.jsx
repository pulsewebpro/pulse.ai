
export default function Home(){
  return (<main style={{padding:"48px",fontFamily:"Inter"}}>
    <h1>Tu cartas online listo para vender hoy</h1>
    <p>Checkout rápido, confianza y repetición de compra.</p>
  </main>);
}
