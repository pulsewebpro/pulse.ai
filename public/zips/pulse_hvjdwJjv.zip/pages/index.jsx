
export default function Home(){
  return (<main style={{padding:"48px",fontFamily:"Inter"}}>
    <h1>Tu plataforma de música con playlists y suscripción</h1>
    <p>Player rápido, catálogo por artista y cobro mensual.</p>
  </main>);
}
