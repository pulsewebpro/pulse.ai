
import Head from "next/head";

export default function Home(){
  return (
    <main style={{minHeight:"100vh",background:"#0a0a0a",color:"#e6f3ff",padding:"32px"}}>
      <Head><title>Pulse Demo</title></Head>
      <h1 style={{fontSize:44,fontWeight:900,marginBottom:8}}>Tu e-commerce online listo para vender hoy</h1>
      <p style={{opacity:.9,marginBottom:18}}>Checkout rápido, confianza y repetición de compra.</p>
      <ul>
        <li style={{marginBottom:6}}>Hero con oferta</li><li style={{marginBottom:6}}>Catálogo</li><li style={{marginBottom:6}}>Opiniones</li><li style={{marginBottom:6}}>FAQ</li><li style={{marginBottom:6}}>CTA Comprar</li>
      </ul>
      <a href="#" style={{display:"inline-block",marginTop:16,padding:"10px 16px",borderRadius:12,background:"#FFD700",color:"#0A0A0A",fontWeight:800,textDecoration:"none"}}>CTA principal</a>
    </main>
  );
}
